import interpreter


def main():
    while True:
        print("Do you want to execute a test file? [Y/N]")
        answer = input(">>> ")
        print()

        if answer == "Y":
            # Loop until a valid file is provided or user chooses to exit
            while True:
                # Get the filename from the command line arguments
                print("Enter a name of the file with .lambda suffix or 'exit' to quit:")
                filename = input(">>> ")

                if filename.lower() == 'exit':
                    print("Exiting file mode...")
                    break  # Exit the file loop and return to the initial prompt

                # Ensure the file has a .lambda suffix
                if not filename.endswith(".lambda"):
                    print("Error: The file must have a .lambda suffix.")
                    continue  # Ask for the filename again

                # Try to read and process the file line by line
                try:
                    with open(filename, "r") as file:
                        for line in file:
                            stripped_line = line.strip()
                            # Skip empty lines or lines with only whitespace
                            if line.strip() == "":
                                continue

                            # Process each line one by one
                            result, error = interpreter.run('<stdin>', stripped_line)

                            if error:
                                print(error.as_string())
                            elif result:
                                print(result)
                    break  # File successfully processed, exit the loop
                except FileNotFoundError:
                    print(f"Error: The file '{filename}' was not found. Please try again.")
                    continue  # Ask for the filename again

        elif answer == "N":
            while True:
                text = input('execute > ')
                if text.strip() == "":
                    continue  # Skip empty input

                result, error = interpreter.run('<stdin>', text)

                if error:
                    print(error.as_string())
                elif result:
                    print(result)

        else:
            print("Enter Y or N")


# Execute main
main()
